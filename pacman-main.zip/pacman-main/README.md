# pacman
Esse jogo é um projeto de POO.

Na versão inicial são oferecidas apenas a imagens e a estrutura inicial do projeto.
